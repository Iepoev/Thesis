<!-- This page is for an official declaration. -->


\vspace*{\fill}
\noindent
\textit{
De auteur geeft de toelating deze masterproef voor consultatie beschikbaar te stellen en delen van de masterproef te kopiëren voor persoonlijk gebruik. Elk ander gebruik valt onder de bepalingen van het auteursrecht, in het bijzonder met betrekking tot de verplichting de bron uitdrukkelijk te vermelden bij het aanhalen van resultaten uit deze masterproef.
}
\vspace*{\fill}

Jeroen De Clerck 	- 	10 augustus 2020

\pagenumbering{gobble}

\newpage