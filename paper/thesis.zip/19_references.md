\footnotesize

<!-- 
Do not edit this page.

References are automatically generated from the BibTex file (library.bib)

...which you should create using your reference manager.
-->

# References
