
# Acknowledgements {.unnumbered}

<!-- This is for acknowledging all of the people who helped out -->

My appreciation goes out to prof. dr. De Pessemier for providing the opportunity to dig my teeth into this topic, which made me research two completely different fields that both interest me a lot.

My eternal gratitude for all the people and organisations that made me extend my academic career 3 years longer than intended; Gentse 12Urenloop vzw for showing that even IT can require getting your hands dirty. Student Kick-Off vzw for providing the greatest opportunity any student could receive and trusting me to tackle it. FaculteitenKonvent Gent for opening the door to the wide world of student engagement at Ghent University. And last but certainly not least, Zeus WPI for providing the springboard towards these experiences. Without the setbacks that we overcame and the experience that I gained, I would never have made it this far.

Thanks to Lorin Werthen for joining me in most of these endeavours and being a voice of guidance into any and all things Machine Learning.

Thanks to Caroline De Brouwer, Niko Strijbol, Sofie De Clerck, Frankie De Clerck \& Felix Van der Jeugt for proofreading this document.


<!-- Use the \newpage command to force a new page -->

\newpage



